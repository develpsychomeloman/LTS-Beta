package com.devel.playerpro2

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player

typealias MenuItems = List<Pair<String, () -> Unit>>

@Composable
fun Chip(label: String, selected: Boolean, icon: ImageVector? = null, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val fg = if (selected) cs.onPrimary else cs.onSurfaceVariant
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(if (selected) cs.primary else cs.surface)
            .clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, Modifier.size(22.dp), tint = fg)
            Spacer(Modifier.width(8.dp))
        }
        Text(label, fontSize = 16.sp, color = fg)
    }
}

@Composable
fun MoreMenu(items: MenuItems) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Filled.MoreVert, "Plus") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            items.forEach { (label, action) ->
                DropdownMenuItem(text = { Text(label) }, onClick = { open = false; action() })
            }
        }
    }
}

@Composable
fun SongRow(m: Media, playing: Boolean, onClick: () -> Unit, menu: MenuItems) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Art(m.uri, false, 200, Modifier.size(62.dp))
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(m.title, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (playing) cs.primary else cs.onSurface)
            Text(m.subtitle, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = cs.onSurfaceVariant)
        }
        MoreMenu(menu)
    }
}

@Composable
fun VideoRow(m: Media, playing: Boolean, onClick: () -> Unit, menu: MenuItems) {
    val cs = MaterialTheme.colorScheme
    val info = (if (m.height > 0) "${m.height}P | " else "") + fmt(m.durationMs)
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Art(m.uri, true, 400, Modifier.width(130.dp).height(80.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(m.title, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                color = if (playing) cs.primary else cs.onSurface)
            Text(info, fontSize = 13.sp, color = cs.onSurfaceVariant)
        }
        MoreMenu(menu)
    }
}

@Composable
fun MediaList(
    items: List<Media>, currentKey: String?, onPlay: (Int) -> Unit,
    menuFor: (Media) -> MenuItems, modifier: Modifier = Modifier
) {
    LazyColumn(modifier) {
        itemsIndexed(items) { i, m ->
            if (m.isVideo) VideoRow(m, m.key == currentKey, { onPlay(i) }, menuFor(m))
            else SongRow(m, m.key == currentKey, { onPlay(i) }, menuFor(m))
        }
    }
}

@Composable
fun GroupRow(title: String, subtitle: String, artUri: Uri?, isVideo: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Art(artUri, isVideo, 200, Modifier.size(62.dp))
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, fontSize = 14.sp, color = cs.onSurfaceVariant)
        }
    }
}

@Composable
fun GroupList(groups: List<Pair<String, List<Media>>>, onOpen: (String) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier) {
        itemsIndexed(groups) { _, g ->
            val first = g.second.first()
            GroupRow(g.first, "${g.second.size} titres", first.uri, first.isVideo) { onOpen(g.first) }
        }
    }
}

@Composable
fun PlaylistCard(
    title: String, count: Int, artUri: Uri?, badge: ImageVector?, badgeTint: Color,
    onClick: () -> Unit, menu: MenuItems
) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(30.dp)).background(cs.surface)
            .clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Art(artUri, false, 220, Modifier.size(80.dp), RoundedCornerShape(22.dp))
        Spacer(Modifier.width(16.dp))
        if (badge != null) {
            Icon(badge, null, Modifier.size(24.dp), tint = badgeTint)
            Spacer(Modifier.width(8.dp))
        }
        Text(title, Modifier.weight(1f), fontSize = 19.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("$count", color = cs.onSurfaceVariant)
        if (menu.isNotEmpty()) MoreMenu(menu)
    }
}

@Composable
fun AddNewCard(onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(30.dp)).background(cs.surface)
            .clickable(onClick = onClick).padding(vertical = 40.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Add, null, tint = cs.onSurfaceVariant)
        Spacer(Modifier.width(12.dp))
        Text("Ajouter un nouveau", fontSize = 18.sp, color = cs.onSurfaceVariant)
    }
}

@Composable
fun MiniPlayer(
    uri: Uri?, title: String, artist: String, isPlaying: Boolean, repeat: Int,
    onOpen: () -> Unit, onToggle: () -> Unit, onRepeat: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val bg = lerp(cs.background, cs.primary, 0.28f)
    Row(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)).background(bg)
            .clickable(onClick = onOpen).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Art(uri, false, 150, Modifier.size(58.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(artist, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = cs.onSurfaceVariant)
        }
        IconButton(onClick = onRepeat) {
            Icon(if (repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                "Répéter", tint = if (repeat != Player.REPEAT_MODE_OFF) cs.primary else cs.onSurface)
        }
        Box(
            Modifier.size(52.dp).clip(CircleShape).border(2.dp, cs.onSurfaceVariant, CircleShape)
                .clickable(onClick = onToggle),
            contentAlignment = Alignment.Center
        ) {
            Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Lecture")
        }
    }
}

@Composable
fun PlaylistDialog(
    title: String, existing: List<String>?,
    onPick: (String) -> Unit, onCreate: (String) -> Unit, onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                existing?.forEach { n -> TextButton(onClick = { onPick(n) }) { Text(n) } }
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Nouvelle playlist") })
            }
        },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onCreate(name.trim()) }) { Text("Créer") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
fun SleepDialog(current: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Minuterie de sommeil") },
        text = {
            Column {
                listOf(0, 15, 30, 45, 60, 90).forEach { m ->
                    TextButton(onClick = { onPick(m) }) {
                        Text((if (m == current) "✓ " else "") + (if (m == 0) "Désactiver" else "$m minutes"))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}

@Composable
fun QueueDialog(player: Player, onDismiss: () -> Unit) {
    val items = remember { List(player.mediaItemCount) { i -> player.getMediaItemAt(i) } }
    val curIdx = player.currentMediaItemIndex
    val accent = MaterialTheme.colorScheme.primary
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("File d'attente") },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                itemsIndexed(items) { i, mi ->
                    Text(
                        mi.mediaMetadata.title?.toString() ?: "", maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = if (i == curIdx) accent else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.fillMaxWidth()
                            .clickable { player.seekTo(i, 0L); onDismiss() }.padding(vertical = 10.dp)
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}

@Composable
fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(32.dp)).background(MaterialTheme.colorScheme.surface),
        content = content
    )
}

@Composable
fun SettingsRow(
    icon: ImageVector, title: String, value: String? = null,
    onClick: (() -> Unit)? = null, trailing: (@Composable () -> Unit)? = null
) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 24.dp, vertical = 22.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, Modifier.size(30.dp), tint = cs.onSurfaceVariant)
        Spacer(Modifier.width(20.dp))
        Text(title, Modifier.weight(1f), fontSize = 18.sp)
        if (value != null) {
            Text(value, fontSize = 14.sp, color = cs.onSurfaceVariant)
            Spacer(Modifier.width(6.dp))
        }
        if (trailing != null) trailing()
        else if (onClick != null) Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = cs.onSurfaceVariant)
    }
}
