package com.devel.playerpro2

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Media(
    val id: Long, val title: String, val artist: String, val album: String,
    val folder: String, val durationMs: Long, val uri: Uri, val isVideo: Boolean,
    val height: Int = 0, val added: Long = 0L
) {
    val key: String get() = (if (isVideo) "v:" else "a:") + id
    val subtitle: String get() = if (isVideo) folder else "$artist – $album"
}

fun Media.toItem(): MediaItem = MediaItem.Builder()
    .setMediaId(key)
    .setUri(uri)
    .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(if (isVideo) folder else artist).build())
    .build()

fun fmt(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

private fun nz(s: String?, d: String): String =
    if (s.isNullOrBlank() || s == "<unknown>") d else s

fun loadAudio(context: Context): List<Media> {
    val out = mutableListOf<Media>()
    try {
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED
        )
        context.contentResolver.query(
            base, proj, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val path = c.getString(5)
                val folder = if (path != null) (File(path).parentFile?.name ?: "Inconnu") else "Inconnu"
                out += Media(
                    id, nz(c.getString(1), "Inconnu"), nz(c.getString(2), "Artiste inconnu"),
                    nz(c.getString(3), "Album inconnu"), folder, c.getLong(4),
                    ContentUris.withAppendedId(base, id), false, 0, c.getLong(6)
                )
            }
        }
    } catch (e: Exception) { }
    return out
}

fun loadVideo(context: Context): List<Media> {
    val out = mutableListOf<Media>()
    try {
        val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME, MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.HEIGHT, MediaStore.Video.Media.DATE_ADDED
        )
        context.contentResolver.query(
            base, proj, null, null, "${MediaStore.Video.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                out += Media(
                    id, nz(c.getString(1), "Vidéo"), "", "", nz(c.getString(2), "Vidéos"),
                    c.getLong(3), ContentUris.withAppendedId(base, id), true, c.getInt(4), c.getLong(5)
                )
            }
        }
    } catch (e: Exception) { }
    return out
}

class Store(context: Context) {
    private val p = context.getSharedPreferences("devel2", Context.MODE_PRIVATE)

    var themeIndex: Int
        get() = p.getInt("theme", 0)
        set(v) { p.edit().putInt("theme", v).apply() }
    var playSeconds: Long
        get() = p.getLong("secs", 0L)
        set(v) { p.edit().putLong("secs", v).apply() }
    var stopOnUnplug: Boolean
        get() = p.getBoolean("unplug", true)
        set(v) { p.edit().putBoolean("unplug", v).apply() }
    var audioFocus: Boolean
        get() = p.getBoolean("focus", true)
        set(v) { p.edit().putBoolean("focus", v).apply() }

    fun favorites(): Set<String> = p.getStringSet("fav", emptySet())!!.toSet()

    fun toggleFav(key: String): Set<String> {
        val s = favorites().toMutableSet()
        if (!s.add(key)) s.remove(key)
        p.edit().putStringSet("fav", s).apply()
        return s
    }

    fun hidden(): Set<String> = p.getStringSet("hidden", emptySet())!!.toSet()

    fun setHidden(key: String, hide: Boolean): Set<String> {
        val s = hidden().toMutableSet()
        if (hide) s.add(key) else s.remove(key)
        p.edit().putStringSet("hidden", s).apply()
        return s
    }

    fun recent(): List<String> {
        val a = JSONArray(p.getString("recent", "[]") ?: "[]")
        return List(a.length()) { i -> a.getString(i) }
    }

    fun counts(): Map<String, Int> {
        val o = JSONObject(p.getString("counts", "{}") ?: "{}")
        val m = HashMap<String, Int>()
        val iter = o.keys()
        while (iter.hasNext()) {
            val k = iter.next()
            m[k] = o.getInt(k)
        }
        return m
    }

    fun recordPlay(key: String) {
        val r = (listOf(key) + recent().filter { it != key }).take(100)
        val c = counts().toMutableMap()
        c[key] = (c[key] ?: 0) + 1
        val o = JSONObject()
        c.forEach { (k, v) -> o.put(k, v) }
        p.edit().putString("recent", JSONArray(r).toString()).putString("counts", o.toString()).apply()
    }

    fun playlists(): Map<String, List<String>> {
        val o = JSONObject(p.getString("pl", "{}") ?: "{}")
        val res = LinkedHashMap<String, List<String>>()
        val iter = o.keys()
        while (iter.hasNext()) {
            val k = iter.next()
            val a = o.getJSONArray(k)
            res[k] = List(a.length()) { i -> a.getString(i) }
        }
        return res
    }

    private fun save(m: Map<String, List<String>>): Map<String, List<String>> {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        p.edit().putString("pl", o.toString()).apply()
        return m
    }

    fun createPlaylist(name: String): Map<String, List<String>> {
        val m = playlists().toMutableMap()
        if (name !in m) m[name] = emptyList()
        return save(m)
    }

    fun addToPlaylist(name: String, key: String): Map<String, List<String>> {
        val m = playlists().toMutableMap()
        val l = m[name].orEmpty()
        if (key !in l) m[name] = l + key
        return save(m)
    }

    fun removeFromPlaylist(name: String, key: String): Map<String, List<String>> {
        val m = playlists().toMutableMap()
        m[name] = m[name].orEmpty() - key
        return save(m)
    }

    fun deletePlaylist(name: String): Map<String, List<String>> {
        val m = playlists().toMutableMap()
        m.remove(name)
        return save(m)
    }
}
