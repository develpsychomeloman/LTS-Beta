package com.devel.playerpro2

import androidx.compose.ui.graphics.Color

class AppTheme(
    val name: String, val bg: Color, val surface: Color,
    val accent: Color, val text: Color, val muted: Color
)

val AppThemes = listOf(
    AppTheme("Mélancolie", Color(0xFF0B0E1A), Color(0xFF131828), Color(0xFF6F7FD8), Color(0xFFE3E6F2), Color(0xFF8A90A8)),
    AppTheme("Pluie grise", Color(0xFF0F1214), Color(0xFF181C1F), Color(0xFF7C97A6), Color(0xFFDDE3E6), Color(0xFF8A979E)),
    AppTheme("Solitude", Color(0xFF0E0B12), Color(0xFF17121D), Color(0xFF8F6FB0), Color(0xFFE6DFEC), Color(0xFF9A8FA6)),
    AppTheme("Cendres", Color(0xFF0C0C0C), Color(0xFF161616), Color(0xFFA0A0A0), Color(0xFFE0E0E0), Color(0xFF808080)),
    AppTheme("Sang séché", Color(0xFF100708), Color(0xFF1B0E10), Color(0xFFB3303C), Color(0xFFEBDADB), Color(0xFF9A7C7F)),
    AppTheme("Le Vide", Color(0xFF000000), Color(0xFF080808), Color(0xFF5E6A70), Color(0xFFC8CED1), Color(0xFF6E777B))
)
