package com.devel.playerpro2

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ThumbCache {
    val cache = LruCache<String, ImageBitmap>(250)
}

suspend fun loadThumb(ctx: Context, uri: Uri, isVideo: Boolean, px: Int): ImageBitmap? =
    withContext(Dispatchers.IO) {
        val k = "$uri@$px"
        val hit = ThumbCache.cache.get(k)
        if (hit != null) return@withContext hit
        var bmp: Bitmap? = null
        if (Build.VERSION.SDK_INT >= 29) {
            try { bmp = ctx.contentResolver.loadThumbnail(uri, Size(px, px), null) } catch (e: Exception) { }
        }
        if (bmp == null) {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(ctx, uri)
                bmp = if (isVideo) r.getFrameAtTime(1_000_000)
                else r.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
                r.release()
            } catch (e: Exception) { }
        }
        val out = bmp?.asImageBitmap()
        if (out != null) ThumbCache.cache.put(k, out)
        out
    }

@Composable
fun Art(
    uri: Uri?, isVideo: Boolean, px: Int, modifier: Modifier,
    shape: Shape = RoundedCornerShape(14.dp)
) {
    val ctx = LocalContext.current
    var bmp by remember(uri) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(uri, px) { if (uri != null) bmp = loadThumb(ctx, uri, isVideo, px) }
    Box(
        modifier.clip(shape).background(MaterialTheme.colorScheme.surface),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(bitmap = b, contentDescription = null, modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop)
        } else if (isVideo) {
            Icon(Icons.Filled.Movie, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            Image(painterResource(R.drawable.ic_skull), null,
                Modifier.fillMaxSize(0.55f).alpha(0.5f),
                colorFilter = ColorFilter.tint(MaterialTheme.colorScheme.onSurfaceVariant))
        }
    }
}
