package com.devel.playerpro2

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer

object PlayerHolder {
    private var player: ExoPlayer? = null
    var equalizer: Equalizer? = null
    var bass: BassBoost? = null

    fun get(ctx: Context): ExoPlayer =
        player ?: ExoPlayer.Builder(ctx.applicationContext)
            .setAudioAttributes(AudioAttributes.DEFAULT, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build().also { player = it }

    fun initEffects(ctx: Context) {
        if (equalizer != null) return
        val id = get(ctx).audioSessionId
        if (id == C.AUDIO_SESSION_ID_UNSET) return
        val sp = ctx.getSharedPreferences("eq", Context.MODE_PRIVATE)
        try {
            val eq = Equalizer(0, id)
            eq.enabled = sp.getBoolean("on", false)
            val saved = sp.getString("levels", null)?.split(",")?.mapNotNull { it.toIntOrNull() }
            if (saved != null && saved.size == eq.numberOfBands.toInt()) {
                saved.forEachIndexed { i, v -> eq.setBandLevel(i.toShort(), v.toShort()) }
            }
            equalizer = eq
            val bb = BassBoost(0, id)
            bb.enabled = true
            if (bb.strengthSupported) bb.setStrength(sp.getInt("bass", 0).toShort())
            bass = bb
        } catch (e: Exception) { }
    }

    fun saveEq(ctx: Context, on: Boolean, preset: String, levels: List<Int>, bassStrength: Int) {
        ctx.getSharedPreferences("eq", Context.MODE_PRIVATE).edit()
            .putBoolean("on", on).putString("preset", preset)
            .putString("levels", levels.joinToString(","))
            .putInt("bass", bassStrength).apply()
    }
}
