package com.devel.playerpro2

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.delay

enum class Screen { Home, Now, Video, Eq, Themes, About, Settings, Hidden, Playback }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        setContent {
            var themeIdx by remember { mutableStateOf(store.themeIndex.coerceIn(0, AppThemes.lastIndex)) }
            val t = AppThemes[themeIdx]
            SideEffect {
                window.statusBarColor = t.bg.toArgb()
                window.navigationBarColor = t.bg.toArgb()
            }
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = t.accent, onPrimary = t.bg,
                    background = t.bg, onBackground = t.text,
                    surface = t.surface, onSurface = t.text,
                    surfaceVariant = t.surface, onSurfaceVariant = t.muted,
                    surfaceContainer = t.surface, surfaceContainerHigh = t.surface,
                    outline = t.muted
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = t.bg) {
                    App(store, themeIdx) { themeIdx = it; store.themeIndex = it }
                }
            }
        }
    }
}

@Composable
fun App(store: Store, themeIdx: Int, onTheme: (Int) -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val player = remember { PlayerHolder.get(ctx) }

    var recentKeys by remember { mutableStateOf(store.recent()) }
    var playCounts by remember { mutableStateOf(store.counts()) }

    // Relie l'appli au service (notification + lecture en arrière-plan)
    DisposableEffect(Unit) {
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        onDispose { MediaController.releaseFuture(future) }
    }

    var cur by remember { mutableStateOf(player.currentMediaItem) }
    var isPlaying by remember { mutableStateOf(player.isPlaying) }
    var shuffle by remember { mutableStateOf(player.shuffleModeEnabled) }
    var repeat by remember { mutableIntStateOf(player.repeatMode) }
    var speed by remember { mutableFloatStateOf(player.playbackParameters.speed) }
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onEvents(p: Player, events: Player.Events) {
                cur = p.currentMediaItem
                isPlaying = p.isPlaying
                shuffle = p.shuffleModeEnabled
                repeat = p.repeatMode
                speed = p.playbackParameters.speed
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val id = mediaItem?.mediaId
                if (!id.isNullOrEmpty()) {
                    store.recordPlay(id)
                    recentKeys = store.recent()
                    playCounts = store.counts()
                }
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l) }
    }

    LaunchedEffect(Unit) {
        PlayerHolder.initEffects(ctx)
        player.setHandleAudioBecomingNoisy(store.stopOnUnplug)
        player.setAudioAttributes(AudioAttributes.DEFAULT, store.audioFocus)
    }
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            delay(5000)
            store.playSeconds = store.playSeconds + 5
        }
    }

    fun hasMedia(): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    }
    val perms = remember {
        if (Build.VERSION.SDK_INT >= 33) arrayOf(
            Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.POST_NOTIFICATIONS
        ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    var granted by remember { mutableStateOf(hasMedia()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasMedia()
    }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(perms) }

    var hiddenSet by remember { mutableStateOf(store.hidden()) }
    val audioRaw = remember(granted) { if (granted) loadAudio(ctx) else emptyList() }
    val videoRaw = remember(granted) { if (granted) loadVideo(ctx) else emptyList() }
    val audio = remember(audioRaw, hiddenSet) { audioRaw.filter { it.key !in hiddenSet } }
    val video = remember(videoRaw, hiddenSet) { videoRaw.filter { it.key !in hiddenSet } }
    val all = audio + video
    val byKey = all.associateBy { it.key }
    val byKeyRaw = (audioRaw + videoRaw).associateBy { it.key }

    var screen by remember { mutableStateOf(Screen.Home) }
    var eqFrom by remember { mutableStateOf(Screen.Home) }
    var tab by remember { mutableIntStateOf(1) }
    var detail by remember { mutableStateOf<Pair<Int, String>?>(null) }
    var query by remember { mutableStateOf("") }
    var searchOpen by remember { mutableStateOf(false) }
    var sortKey by remember { mutableIntStateOf(0) }
    var asc by remember { mutableStateOf(true) }
    var sortMenu by remember { mutableStateOf(false) }
    var favs by remember { mutableStateOf(store.favorites()) }
    var playlists by remember { mutableStateOf(store.playlists()) }
    var addTarget by remember { mutableStateOf<Media?>(null) }
    var showNew by remember { mutableStateOf(false) }
    var sleepMin by remember { mutableIntStateOf(0) }
    var showSleep by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var unplug by remember { mutableStateOf(store.stopOnUnplug) }
    var focus by remember { mutableStateOf(store.audioFocus) }

    LaunchedEffect(sleepMin) {
        if (sleepMin > 0) {
            delay(sleepMin * 60_000L)
            player.pause()
            sleepMin = 0
        }
    }

    BackHandler(enabled = screen != Screen.Home || detail != null || searchOpen) {
        when (screen) {
            Screen.Video -> { player.pause(); screen = Screen.Home }
            Screen.Eq -> screen = eqFrom
            Screen.Now -> screen = Screen.Home
            Screen.Themes, Screen.About, Screen.Hidden, Screen.Playback -> screen = Screen.Settings
            Screen.Settings -> screen = Screen.Home
            Screen.Home -> { if (detail != null) detail = null else searchOpen = false }
        }
    }

    fun play(list: List<Media>, index: Int) {
        player.setMediaItems(list.map { it.toItem() }, index, 0L)
        player.prepare()
        player.play()
        if (list[index].isVideo) screen = Screen.Video
    }

    fun detailList(kind: Int, name: String): List<Media> = when (kind) {
        2 -> when (name) {
            "Chansons aimées" -> all.filter { it.key in favs }
            "Lue dernièrement" -> recentKeys.mapNotNull { byKey[it] }
            "Le plus joué" -> playCounts.entries.sortedByDescending { it.value }.take(100).mapNotNull { byKey[it.key] }
            else -> (playlists[name] ?: emptyList()).mapNotNull { byKey[it] }
        }
        3 -> all.filter { it.folder == name }
        4 -> audio.filter { it.artist == name }
        5 -> audio.filter { it.album == name }
        else -> emptyList()
    }

    fun menuFor(m: Media): MenuItems {
        val l = mutableListOf<Pair<String, () -> Unit>>()
        l.add((if (m.key in favs) "Retirer des favoris" else "Ajouter aux favoris") to { favs = store.toggleFav(m.key) })
        l.add("Ajouter à une playlist" to { addTarget = m })
        val d = detail
        if (d != null && d.first == 2 && playlists.containsKey(d.second)) {
            l.add("Retirer de la playlist" to { playlists = store.removeFromPlaylist(d.second, m.key) })
        }
        l.add("Masquer" to { hiddenSet = store.setHidden(m.key, true) })
        return l
    }

    fun sorted(l: List<Media>): List<Media> {
        val s = when (sortKey) {
            0 -> l.sortedBy { it.title.lowercase() }
            1 -> l.sortedBy { it.artist.lowercase() }
            2 -> l.sortedBy { it.album.lowercase() }
            3 -> l.sortedBy { it.durationMs }
            else -> l.sortedBy { it.added }
        }
        return if (asc) s else s.reversed()
    }

    val q = query.trim()
    fun match(m: Media): Boolean =
        q.isEmpty() || m.title.contains(q, true) || m.artist.contains(q, true) || m.album.contains(q, true)

    val curKey = cur?.mediaId
    val curTitle = cur?.mediaMetadata?.title?.toString() ?: ""
    val curArtist = cur?.mediaMetadata?.artist?.toString() ?: ""
    val curIsVideo = curKey?.startsWith("v:") == true
    val curUri = cur?.localConfiguration?.uri

    fun cycleRepeat() {
        player.repeatMode = when (player.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    when (screen) {
        Screen.Now -> {
            val nowMenu = mutableListOf<Pair<String, () -> Unit>>()
            nowMenu.add((if (shuffle) "Désactiver l'aléatoire" else "Activer l'aléatoire") to { player.shuffleModeEnabled = !shuffle })
            nowMenu.add("Ajouter à une playlist" to { addTarget = byKey[curKey ?: ""] })
            nowMenu.add("File d'attente" to { showQueue = true })
            nowMenu.add("Minuterie de sommeil" to { showSleep = true })
            NowPlayingScreen(
                player, cur, isPlaying, repeat, speed,
                fav = (curKey ?: "") in favs,
                onFav = { curKey?.let { favs = store.toggleFav(it) } },
                menu = nowMenu,
                onEq = { eqFrom = Screen.Now; screen = Screen.Eq },
                onBack = { screen = Screen.Home }
            )
        }
        Screen.Video -> {
            val videoMenu = mutableListOf<Pair<String, () -> Unit>>()
            videoMenu.add("Écouter l'audio seulement" to { screen = Screen.Home })
            videoMenu.add("Ajouter à une playlist" to { addTarget = byKey[curKey ?: ""] })
            videoMenu.add("Minuterie de sommeil" to { showSleep = true })
            VideoScreen(
                player, cur, isPlaying, speed, videoMenu,
                onAudioOnly = { screen = Screen.Home },
                onQueue = { showQueue = true },
                onBack = { player.pause(); screen = Screen.Home }
            )
        }
        Screen.Eq -> EqualizerScreen(player, cur, isPlaying) { screen = eqFrom }
        Screen.Themes -> ThemesScreen(themeIdx, onTheme) { screen = Screen.Settings }
        Screen.About -> AboutScreen { screen = Screen.Settings }
        Screen.Hidden -> HiddenScreen(
            hiddenSet.mapNotNull { byKeyRaw[it] },
            onShow = { m -> hiddenSet = store.setHidden(m.key, false) }
        ) { screen = Screen.Settings }
        Screen.Playback -> PlaybackSettingsScreen(
            unplug, focus,
            onUnplug = { v -> unplug = v; store.stopOnUnplug = v; player.setHandleAudioBecomingNoisy(v) },
            onFocus = { v -> focus = v; store.audioFocus = v; player.setAudioAttributes(AudioAttributes.DEFAULT, v) }
        ) { screen = Screen.Settings }
        Screen.Settings -> {
            val secs = store.playSeconds
            SettingsScreen(
                themeName = AppThemes[themeIdx].name,
                sleepText = if (sleepMin > 0) "$sleepMin min" else "Désactiver",
                playTime = "${secs / 3600}h ${(secs % 3600) / 60}m",
                hiddenCount = hiddenSet.size,
                onTheme = { screen = Screen.Themes },
                onSleep = { showSleep = true },
                onHidden = { screen = Screen.Hidden },
                onPlayback = { screen = Screen.Playback },
                onNotif = {
                    try {
                        ctx.startActivity(
                            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                        )
                    } catch (e: Exception) { }
                },
                onAbout = { screen = Screen.About },
                onBack = { screen = Screen.Home }
            )
        }
        Screen.Home -> Column(Modifier.fillMaxSize()) {
            // En-tête
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 20.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(painterResource(R.drawable.ic_skull), null, Modifier.size(34.dp),
                    colorFilter = ColorFilter.tint(cs.primary))
                Spacer(Modifier.width(10.dp))
                Text("FullPlayer", Modifier.weight(1f), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                IconButton(onClick = { searchOpen = !searchOpen; if (!searchOpen) query = "" }) {
                    Icon(Icons.Filled.Search, "Rechercher", Modifier.size(28.dp))
                }
                Box {
                    IconButton(onClick = { sortMenu = true }) {
                        Icon(Icons.AutoMirrored.Filled.Sort, "Trier", Modifier.size(28.dp))
                    }
                    DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                        listOf("Titre", "Artiste", "Album", "Durée", "Date d'ajout").forEachIndexed { i, s ->
                            DropdownMenuItem(
                                text = { Text((if (sortKey == i) "✓ " else "") + s) },
                                onClick = { sortKey = i; sortMenu = false }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text(if (asc) "Ordre croissant" else "Ordre décroissant") },
                            onClick = { asc = !asc; sortMenu = false }
                        )
                    }
                }
                IconButton(onClick = { screen = Screen.Settings }) {
                    Icon(Icons.Filled.Settings, "Paramètres", Modifier.size(28.dp))
                }
            }
            if (searchOpen) {
                OutlinedTextField(
                    query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    placeholder = { Text("Rechercher") }, singleLine = true,
                    leadingIcon = { Icon(Icons.Filled.Search, null) }
                )
                Spacer(Modifier.height(8.dp))
            }
            // Onglets
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                item { Chip("Vidéos", tab == 0, Icons.Filled.Movie) { tab = 0; detail = null } }
                item {
                    Box(Modifier.width(1.dp).height(30.dp).background(cs.onSurfaceVariant.copy(alpha = 0.5f)))
                }
                listOf("Chansons", "Playlists", "Dossiers", "Artistes", "Albums").forEachIndexed { i, s ->
                    item { Chip(s, tab == i + 1) { tab = i + 1; detail = null } }
                }
            }
            Spacer(Modifier.height(8.dp))
            // Contenu
            Box(Modifier.weight(1f)) {
                val d = detail
                if (!granted && d == null && tab != 2) {
                    Text("Autorise l'accès à tes fichiers pour voir ta musique et tes vidéos.",
                        Modifier.padding(24.dp), color = cs.onSurfaceVariant)
                }
                if (d != null) {
                    val items = detailList(d.first, d.second)
                    Column {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { detail = null }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") }
                            Text(d.second, Modifier.weight(1f), fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            IconButton(onClick = { if (items.isNotEmpty()) play(items, 0) }) {
                                Icon(Icons.Filled.PlayArrow, "Tout lire", tint = cs.primary)
                            }
                        }
                        if (items.isEmpty()) Text("Aucun titre.", Modifier.padding(24.dp), color = cs.onSurfaceVariant)
                        MediaList(items, curKey, { i -> play(items, i) }, { m -> menuFor(m) }, Modifier.weight(1f))
                    }
                } else when (tab) {
                    0 -> {
                        val vids = sorted(video.filter { match(it) })
                        Column {
                            Text("${vids.size} vidéos", Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
                                color = cs.onSurfaceVariant)
                            MediaList(vids, curKey, { i -> play(vids, i) }, { m -> menuFor(m) }, Modifier.weight(1f))
                        }
                    }
                    1 -> {
                        val songs = sorted(audio.filter { match(it) })
                        MediaList(songs, curKey, { i -> play(songs, i) }, { m -> menuFor(m) })
                    }
                    2 -> {
                        val favList = all.filter { it.key in favs }
                        val recentList = recentKeys.mapNotNull { byKey[it] }
                        val topList = playCounts.entries.sortedByDescending { it.value }.take(100).mapNotNull { byKey[it.key] }
                        LazyColumn {
                            item { AddNewCard { showNew = true } }
                            item {
                                PlaylistCard("Chansons aimées", favList.size, favList.firstOrNull()?.uri,
                                    Icons.Filled.Favorite, Color(0xFFE57373), { detail = 2 to "Chansons aimées" }, emptyList())
                            }
                            item {
                                PlaylistCard("Lue dernièrement", recentList.size, recentList.firstOrNull()?.uri,
                                    Icons.Filled.Schedule, cs.onSurface, { detail = 2 to "Lue dernièrement" }, emptyList())
                            }
                            item {
                                PlaylistCard("Le plus joué", topList.size, topList.firstOrNull()?.uri,
                                    Icons.Filled.Star, cs.onSurface, { detail = 2 to "Le plus joué" }, emptyList())
                            }
                            items(playlists.keys.toList()) { name ->
                                val l = (playlists[name] ?: emptyList()).mapNotNull { byKey[it] }
                                PlaylistCard(name, playlists[name]?.size ?: 0, l.firstOrNull()?.uri, null, cs.onSurface,
                                    { detail = 2 to name },
                                    listOf("Supprimer" to { playlists = store.deletePlaylist(name) }))
                            }
                        }
                    }
                    3 -> GroupList(all.groupBy { it.folder }.toList().sortedBy { it.first.lowercase() }, onOpen = { n -> detail = 3 to n })
                    4 -> GroupList(audio.groupBy { it.artist }.toList().sortedBy { it.first.lowercase() }, onOpen = { n -> detail = 4 to n })
                    else -> GroupList(audio.groupBy { it.album }.toList().sortedBy { it.first.lowercase() }, onOpen = { n -> detail = 5 to n })
                }
            }
            if (cur != null) {
                MiniPlayer(
                    curUri, curTitle, curArtist, isPlaying, repeat,
                    onOpen = { screen = if (curIsVideo) Screen.Video else Screen.Now },
                    onToggle = { if (player.isPlaying) player.pause() else player.play() },
                    onRepeat = { cycleRepeat() }
                )
            }
        }
    }

    addTarget?.let { m ->
        PlaylistDialog(
            "Ajouter à une playlist", playlists.keys.toList(),
            onPick = { n -> playlists = store.addToPlaylist(n, m.key); addTarget = null },
            onCreate = { n ->
                store.createPlaylist(n)
                playlists = store.addToPlaylist(n, m.key)
                addTarget = null
            },
            onDismiss = { addTarget = null }
        )
    }
    if (showNew) {
        PlaylistDialog(
            "Nouvelle playlist", null,
            onPick = {},
            onCreate = { n -> playlists = store.createPlaylist(n); showNew = false },
            onDismiss = { showNew = false }
        )
    }
    if (showSleep) {
        SleepDialog(sleepMin, onPick = { m -> sleepMin = m; showSleep = false }, onDismiss = { showSleep = false })
    }
    if (showQueue) QueueDialog(player) { showQueue = false }
}
