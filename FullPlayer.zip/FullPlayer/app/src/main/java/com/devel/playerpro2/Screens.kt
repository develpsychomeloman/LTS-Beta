package com.devel.playerpro2

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.view.WindowManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
fun ScreenHeader(title: String, onBack: () -> Unit) {
    Column {
        Box(
            Modifier.padding(16.dp).size(52.dp).clip(CircleShape)
                .background(MaterialTheme.colorScheme.surface).clickable(onClick = onBack),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") }
        Text(title, Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
            fontSize = 38.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun NowPlayingScreen(
    player: Player, cur: MediaItem?, isPlaying: Boolean, repeat: Int, speed: Float,
    fav: Boolean, onFav: () -> Unit, menu: MenuItems, onEq: () -> Unit, onBack: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val bg = lerp(cs.background, cs.primary, 0.28f)
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var dragVal by remember { mutableFloatStateOf(0f) }
    var speedMenu by remember { mutableStateOf(false) }

    LaunchedEffect(player) {
        while (true) {
            if (!dragging) {
                pos = player.currentPosition
                dur = player.duration.coerceAtLeast(0L)
            }
            delay(400)
        }
    }

    val title = cur?.mediaMetadata?.title?.toString() ?: ""
    val artist = cur?.mediaMetadata?.artist?.toString() ?: ""

    Column(Modifier.fillMaxSize().background(bg).padding(horizontal = 28.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.KeyboardArrowDown, "Réduire") }
        }
        Art(cur?.localConfiguration?.uri, false, 900,
            Modifier.fillMaxWidth().aspectRatio(1f), RoundedCornerShape(32.dp))
        Spacer(Modifier.height(24.dp))
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = cs.primary,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(artist, Modifier.weight(1f), color = cs.onSurfaceVariant, maxLines = 1,
                overflow = TextOverflow.Ellipsis)
            IconButton(onClick = onFav) {
                Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favori", tint = cs.primary)
            }
            MoreMenu(menu)
        }
        Spacer(Modifier.weight(1f))
        val maxV = if (dur > 0) dur.toFloat() else 1f
        Slider(
            value = (if (dragging) dragVal else pos.toFloat()).coerceIn(0f, maxV),
            onValueChange = { dragging = true; dragVal = it },
            onValueChangeFinished = { player.seekTo(dragVal.toLong()); dragging = false },
            valueRange = 0f..maxV,
            colors = SliderDefaults.colors(
                thumbColor = cs.primary, activeTrackColor = cs.primary,
                inactiveTrackColor = cs.primary.copy(alpha = 0.25f)
            )
        )
        Row(Modifier.fillMaxWidth()) {
            Text(fmt(if (dragging) dragVal.toLong() else pos), fontSize = 12.sp, color = cs.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            Text(fmt(dur), fontSize = 12.sp, color = cs.onSurfaceVariant)
        }
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { player.seekToPrevious() }, modifier = Modifier.size(72.dp)) {
                Icon(Icons.Filled.SkipPrevious, "Précédent", Modifier.size(48.dp), tint = cs.primary)
            }
            IconButton(onClick = { if (player.isPlaying) player.pause() else player.play() },
                modifier = Modifier.size(96.dp)) {
                Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Lecture",
                    Modifier.size(78.dp), tint = cs.primary)
            }
            IconButton(onClick = { player.seekToNext() }, modifier = Modifier.size(72.dp)) {
                Icon(Icons.Filled.SkipNext, "Suivant", Modifier.size(48.dp), tint = cs.primary)
            }
        }
        Spacer(Modifier.weight(1f))
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onEq) { Icon(Icons.Filled.Tune, "Égaliseur", Modifier.size(30.dp)) }
            Box(
                Modifier.weight(1f).padding(horizontal = 12.dp).clip(RoundedCornerShape(50))
                    .background(cs.surface.copy(alpha = 0.6f)).clickable { speedMenu = true }
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Vitesse ${speed}x", color = cs.onSurfaceVariant)
                DropdownMenu(expanded = speedMenu, onDismissRequest = { speedMenu = false }) {
                    listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                        DropdownMenuItem(text = { Text("${s}x" ) },
                            onClick = { player.setPlaybackSpeed(s); speedMenu = false })
                    }
                }
            }
            IconButton(onClick = {
                player.repeatMode = when (repeat) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
            }) {
                Icon(if (repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    "Répéter", Modifier.size(30.dp),
                    tint = if (repeat != Player.REPEAT_MODE_OFF) cs.primary else cs.onSurface)
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

class EqPreset(val name: String, val icon: ImageVector, val curve: List<Int>?, val bass: Int = 0)

val EqPresets = listOf(
    EqPreset("Personnalisé(e)", Icons.Filled.GraphicEq, null),
    EqPreset("Amplificateur de basses", Icons.Filled.Speaker, listOf(6, 4, 0, 0, 0), 800),
    EqPreset("Booster vocal", Icons.Filled.Mic, listOf(-2, 0, 4, 3, -1)),
    EqPreset("Booster d'aigus", Icons.Filled.Hearing, listOf(-2, -1, 0, 4, 6)),
    EqPreset("Normal", Icons.Filled.Mood, listOf(0, 0, 0, 0, 0)),
    EqPreset("Pop", Icons.Filled.MusicNote, listOf(-1, 3, 5, 2, -1)),
    EqPreset("Hip-Hop", Icons.Filled.Headphones, listOf(5, 4, 0, 1, 3)),
    EqPreset("Rock n roll", Icons.Filled.Audiotrack, listOf(5, 3, -1, 3, 5)),
    EqPreset("Électronique", Icons.Filled.Album, listOf(5, 3, 0, 3, 5)),
    EqPreset("Heavy metal", Icons.Filled.LibraryMusic, listOf(5, 2, -2, 4, 4)),
    EqPreset("R&B", Icons.Filled.Headphones, listOf(3, 6, 2, -2, 3)),
    EqPreset("Folk", Icons.Filled.MusicNote, listOf(3, 1, 0, 2, 1)),
    EqPreset("Dance", Icons.Filled.Album, listOf(6, 4, 0, 2, 3)),
    EqPreset("Jazz", Icons.Filled.Audiotrack, listOf(3, 2, -2, 2, 4)),
    EqPreset("Classique", Icons.Filled.LibraryMusic, listOf(4, 3, -1, 2, 4))
)

@Composable
fun VSlider(value: Float, min: Float, max: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    val accent = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)
    val cb by rememberUpdatedState(onChange)
    Canvas(
        modifier.width(44.dp).height(170.dp)
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    cb(min + (1f - (o.y / size.height).coerceIn(0f, 1f)) * (max - min))
                }
            }
            .pointerInput(Unit) {
                detectDragGestures { change, _ ->
                    change.consume()
                    cb(min + (1f - (change.position.y / size.height).coerceIn(0f, 1f)) * (max - min))
                }
            }
    ) {
        val cx = size.width / 2f
        drawLine(track, Offset(cx, 0f), Offset(cx, size.height), strokeWidth = 4f)
        val frac = ((value - min) / (max - min)).coerceIn(0f, 1f)
        val y = size.height * (1f - frac)
        drawLine(accent, Offset(cx, size.height / 2f), Offset(cx, y), strokeWidth = 4f)
        drawCircle(Color.White, 14f, Offset(cx, y))
    }
}

@Composable
fun EqualizerScreen(player: Player, cur: MediaItem?, isPlaying: Boolean, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    remember { PlayerHolder.initEffects(ctx) }
    val eq = PlayerHolder.equalizer
    val bass = PlayerHolder.bass
    val sp = remember { ctx.getSharedPreferences("eq", Context.MODE_PRIVATE) }
    var on by remember { mutableStateOf(eq?.enabled ?: false) }
    var preset by remember { mutableStateOf(sp.getString("preset", "Normal") ?: "Normal") }
    val n = eq?.numberOfBands?.toInt() ?: 0
    val levels = remember {
        mutableStateListOf<Int>().also { l ->
            for (b in 0 until n) l.add(eq!!.getBandLevel(b.toShort()).toInt())
        }
    }
    val lo = eq?.bandLevelRange?.get(0)?.toInt() ?: -1500
    val hi = eq?.bandLevelRange?.get(1)?.toInt() ?: 1500

    fun bassNow(): Int = if (bass != null && bass.strengthSupported) bass.roundedStrength.toInt() else 0
    fun persist() { PlayerHolder.saveEq(ctx, on, preset, levels.toList(), bassNow()) }

    fun applyPreset(p: EqPreset) {
        preset = p.name
        if (eq != null) {
            val c = p.curve
            if (c != null) {
                for (b in 0 until n) {
                    val pos = if (n == 1) 0f else b * 4f / (n - 1)
                    val i0 = pos.toInt().coerceIn(0, 4)
                    val i1 = (i0 + 1).coerceAtMost(4)
                    val t = pos - i0
                    val db = c[i0] * (1f - t) + c[i1] * t
                    val level = (db * 100).toInt().coerceIn(lo, hi)
                    eq.setBandLevel(b.toShort(), level.toShort())
                    levels[b] = level
                }
                if (bass != null && bass.strengthSupported) bass.setStrength(p.bass.toShort())
            }
            if (!on) { on = true; eq.enabled = true }
        }
        persist()
    }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize().background(lerp(cs.background, cs.primary, 0.28f)),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(2) }) {
            Column {
                Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Art(cur?.localConfiguration?.uri, false, 150, Modifier.size(58.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(cur?.mediaMetadata?.title?.toString() ?: "Aucune lecture", fontSize = 18.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(cur?.mediaMetadata?.artist?.toString() ?: "", fontSize = 14.sp,
                            maxLines = 1, color = cs.onSurfaceVariant)
                    }
                    IconButton(onClick = { if (player.isPlaying) player.pause() else player.play() }) {
                        Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Lecture",
                            Modifier.size(34.dp))
                    }
                }
                IconButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Icon(Icons.Filled.KeyboardArrowDown, "Fermer")
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Égaliseur", Modifier.weight(1f), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Switch(checked = on, onCheckedChange = {
                        on = it
                        eq?.enabled = it
                        persist()
                    })
                }
                if (eq == null) {
                    Text("Égaliseur indisponible sur cet appareil.", Modifier.padding(vertical = 24.dp),
                        color = cs.onSurfaceVariant)
                } else {
                    Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        for (b in 0 until n) {
                            val hz = eq.getCenterFreq(b.toShort()) / 1000
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${levels[b] / 100}", fontSize = 12.sp, color = cs.onSurfaceVariant)
                                VSlider(
                                    value = levels[b].toFloat(), min = lo.toFloat(), max = hi.toFloat(),
                                    onChange = {
                                        val v = it.toInt().coerceIn(lo, hi)
                                        levels[b] = v
                                        eq.setBandLevel(b.toShort(), v.toShort())
                                        preset = "Personnalisé(e)"
                                        persist()
                                    }
                                )
                                Text(if (hz >= 1000) "${(hz + 500) / 1000}K" else "$hz",
                                    fontSize = 12.sp, color = cs.onSurfaceVariant)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
        items(EqPresets) { p ->
            val sel = p.name == preset
            Column(
                Modifier.clip(RoundedCornerShape(26.dp))
                    .background(if (sel) cs.primary.copy(alpha = 0.25f) else cs.surface.copy(alpha = 0.5f))
                    .border(1.5.dp, if (sel) cs.primary else cs.onSurfaceVariant.copy(alpha = 0.35f),
                        RoundedCornerShape(26.dp))
                    .clickable { applyPreset(p) }.padding(20.dp)
            ) {
                Icon(p.icon, null, Modifier.size(34.dp), tint = if (sel) cs.primary else cs.onSurfaceVariant)
                Spacer(Modifier.height(18.dp))
                Text(p.name, fontSize = 17.sp)
            }
        }
    }
}

@Composable
fun ThemesScreen(current: Int, onPick: (Int) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Thème", onBack)
        LazyColumn {
            itemsIndexed(AppThemes) { i, t ->
                Row(
                    Modifier.fillMaxWidth().clickable { onPick(i) }.padding(vertical = 12.dp, horizontal = 24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(44.dp).background(t.bg, CircleShape).border(4.dp, t.accent, CircleShape))
                    Spacer(Modifier.width(18.dp))
                    Text(t.name, Modifier.weight(1f), fontSize = 18.sp)
                    if (i == current) Icon(Icons.Filled.Check, null, tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    themeName: String, sleepText: String, playTime: String, hiddenCount: Int,
    onTheme: () -> Unit, onSleep: () -> Unit, onHidden: () -> Unit, onPlayback: () -> Unit,
    onNotif: () -> Unit, onAbout: () -> Unit, onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Paramètres", onBack)
        SettingsCard {
            SettingsRow(Icons.Filled.Schedule, "Temps de lecture", playTime)
            SettingsRow(Icons.Filled.Palette, "Thème", themeName, onTheme)
            SettingsRow(Icons.Filled.Bedtime, "Minuterie de sommeil", sleepText, onSleep)
        }
        SettingsCard {
            SettingsRow(Icons.Filled.VisibilityOff, "Fichiers masqués", "$hiddenCount fichier(s)", onHidden)
            SettingsRow(Icons.Filled.Headphones, "Paramètres de lecture", null, onPlayback)
            SettingsRow(Icons.Filled.Notifications, "Paramètres de notifications", null, onNotif)
        }
        SettingsCard {
            SettingsRow(Icons.Filled.Info, "À propos", null, onAbout)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun HiddenScreen(items: List<Media>, onShow: (Media) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Fichiers masqués", onBack)
        if (items.isEmpty()) {
            Text("Aucun fichier masqué.", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LazyColumn {
            itemsIndexed(items) { _, m ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(m.title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    TextButton(onClick = { onShow(m) }) { Text("Afficher") }
                }
            }
        }
    }
}

@Composable
fun PlaybackSettingsScreen(
    unplug: Boolean, focus: Boolean,
    onUnplug: (Boolean) -> Unit, onFocus: (Boolean) -> Unit, onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Paramètres de lecture", onBack)
        SettingsCard {
            SettingsRow(Icons.Filled.Headphones, "Pause si le casque est débranché",
                trailing = { Switch(checked = unplug, onCheckedChange = onUnplug) })
            SettingsRow(Icons.Filled.Speaker, "Pause pendant les appels et autres sons",
                trailing = { Switch(checked = focus, onCheckedChange = onFocus) })
        }
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val accent = MaterialTheme.colorScheme.primary
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("À propos", onBack)
        Column(
            Modifier.fillMaxWidth().weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                Modifier.size(200.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface),
                contentAlignment = Alignment.Center
            ) {
                Image(painterResource(R.drawable.ic_skull), null, Modifier.size(130.dp),
                    colorFilter = ColorFilter.tint(accent))
            }
            Spacer(Modifier.height(24.dp))
            Text("FullPlayer", style = MaterialTheme.typography.headlineMedium, color = accent)
            Text("Version 3.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))
            Text("Créé par", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Develpsychomeloman", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(24.dp))
            Text("Lecteur audio et vidéo, sans pub.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun Pill(icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(72.dp).clip(RoundedCornerShape(50)).background(Color(0xFF1A1A1A))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, Modifier.size(30.dp), tint = Color.White) }
}

@Composable
fun VideoScreen(
    player: ExoPlayer, cur: MediaItem?, isPlaying: Boolean, speed: Float,
    menu: MenuItems, onAudioOnly: () -> Unit, onQueue: () -> Unit, onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val act = ctx as? Activity
    val audio = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var land by remember { mutableStateOf(false) }
    var locked by remember { mutableStateOf(false) }
    var visible by remember { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) }
    var hint by remember { mutableStateOf<String?>(null) }
    var hintTick by remember { mutableIntStateOf(0) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var dragVal by remember { mutableFloatStateOf(0f) }
    var speedMenu by remember { mutableStateOf(false) }
    var startX by remember { mutableFloatStateOf(0f) }
    var bright by remember {
        mutableFloatStateOf((act?.window?.attributes?.screenBrightness ?: -1f).let { if (it < 0f) 0.5f else it })
    }
    var vol by remember {
        mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol)
    }

    DisposableEffect(Unit) {
        onDispose {
            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            act?.window?.let { w ->
                val lp = w.attributes
                lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                w.attributes = lp
            }
        }
    }
    LaunchedEffect(player) {
        while (true) {
            if (!dragging) {
                pos = player.currentPosition
                dur = player.duration.coerceAtLeast(0L)
            }
            delay(300)
        }
    }
    LaunchedEffect(visible, isPlaying, locked, tick) {
        if (visible && isPlaying) {
            delay(4000)
            visible = false
        }
    }
    LaunchedEffect(hintTick) {
        if (hint != null) {
            delay(900)
            hint = null
        }
    }

    fun showHint(t: String) { hint = t; hintTick++ }
    fun seekBy(ms: Long) {
        player.seekTo((player.currentPosition + ms).coerceAtLeast(0L))
        showHint(if (ms > 0) "+${ms / 1000} s" else "${ms / 1000} s")
        tick++
    }

    val title = cur?.mediaMetadata?.title?.toString() ?: ""
    val white = Color.White
    val maxV = if (dur > 0) dur.toFloat() else 1f

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    this.player = player
                    useController = false
                    keepScreenOn = true
                }
            },
            modifier = Modifier.fillMaxSize(),
            onRelease = { it.player = null }
        )
        // Couche de gestes : toucher = afficher/masquer, double toucher = +/-10 s,
        // glisser vertical à gauche = luminosité, à droite = volume
        Box(
            Modifier.fillMaxSize()
                .pointerInput(locked) {
                    detectTapGestures(
                        onTap = { visible = !visible; tick++ },
                        onDoubleTap = { o ->
                            if (!locked) seekBy(if (o.x < size.width / 2f) -10_000L else 10_000L)
                        }
                    )
                }
                .pointerInput(locked) {
                    if (!locked) {
                        detectVerticalDragGestures(
                            onDragStart = { startX = it.x },
                            onVerticalDrag = { change, dy ->
                                change.consume()
                                val d = -dy / size.height * 1.5f
                                if (startX < size.width / 2f) {
                                    bright = (bright + d).coerceIn(0.02f, 1f)
                                    act?.window?.let { w ->
                                        val lp = w.attributes
                                        lp.screenBrightness = bright
                                        w.attributes = lp
                                    }
                                    showHint("Luminosité ${(bright * 100).toInt()}%")
                                } else {
                                    vol = (vol + d).coerceIn(0f, 1f)
                                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, (vol * maxVol).roundToInt(), 0)
                                    showHint("Volume ${(vol * 100).toInt()}%")
                                }
                            }
                        )
                    }
                }
        )

        if (visible && !locked) {
            // Barre du haut
            Row(
                Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(start = 12.dp, end = 8.dp, top = 28.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = white) }
                Text(title, Modifier.weight(1f).padding(horizontal = 8.dp), color = white,
                    fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Box {
                    Row(
                        Modifier.clip(RoundedCornerShape(50)).clickable { speedMenu = true; tick++ }.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Speed, "Vitesse", tint = white)
                        Text("${speed}x", color = white, fontSize = 12.sp)
                    }
                    DropdownMenu(expanded = speedMenu, onDismissRequest = { speedMenu = false }) {
                        listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                            DropdownMenuItem(text = { Text("${s}x") },
                                onClick = { player.setPlaybackSpeed(s); speedMenu = false })
                        }
                    }
                }
                Box {
                    var more by remember { mutableStateOf(false) }
                    IconButton(onClick = { more = true; tick++ }) { Icon(Icons.Filled.MoreVert, "Plus", tint = white) }
                    DropdownMenu(expanded = more, onDismissRequest = { more = false }) {
                        menu.forEach { (label, action) ->
                            DropdownMenuItem(text = { Text(label) }, onClick = { more = false; action() })
                        }
                    }
                }
            }
            // Commandes du centre
            Row(
                Modifier.align(Alignment.Center),
                horizontalArrangement = Arrangement.spacedBy(48.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { seekBy(-10_000L) }, modifier = Modifier.size(72.dp)) {
                    Icon(Icons.Filled.FastRewind, "-10 s", Modifier.size(56.dp), tint = white)
                }
                IconButton(
                    onClick = { if (player.isPlaying) player.pause() else player.play(); tick++ },
                    modifier = Modifier.size(96.dp)
                ) {
                    Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Lecture",
                        Modifier.size(80.dp), tint = white)
                }
                IconButton(onClick = { seekBy(10_000L) }, modifier = Modifier.size(72.dp)) {
                    Icon(Icons.Filled.FastForward, "+10 s", Modifier.size(56.dp), tint = white)
                }
            }
            // Barre du bas
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 16.dp, vertical = 24.dp)
            ) {
                Slider(
                    value = (if (dragging) dragVal else pos.toFloat()).coerceIn(0f, maxV),
                    onValueChange = { dragging = true; dragVal = it; tick++ },
                    onValueChangeFinished = { player.seekTo(dragVal.toLong()); dragging = false },
                    valueRange = 0f..maxV,
                    colors = SliderDefaults.colors(
                        thumbColor = white, activeTrackColor = white,
                        inactiveTrackColor = white.copy(alpha = 0.3f)
                    )
                )
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                    Text(fmt(if (dragging) dragVal.toLong() else pos), color = white, fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    Text(fmt(dur), color = white, fontSize = 12.sp)
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Pill(Icons.Filled.Headphones, Modifier.weight(1f)) { onAudioOnly() }
                    Pill(Icons.Filled.ScreenRotation, Modifier.weight(1f)) {
                        land = !land
                        act?.requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                        else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                        tick++
                    }
                    Pill(Icons.Filled.Lock, Modifier.weight(1f)) { locked = true; visible = false }
                    Pill(Icons.AutoMirrored.Filled.QueueMusic, Modifier.weight(1f)) { onQueue() }
                }
            }
        }
        // Bouton de déverrouillage quand l'écran est verrouillé
        if (locked && visible) {
            Box(
                Modifier.align(Alignment.CenterStart).padding(24.dp).size(60.dp).clip(CircleShape)
                    .background(Color(0xAA000000)).clickable { locked = false; tick++ },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.LockOpen, "Déverrouiller", tint = white) }
        }
        // Indications (luminosité, volume, saut)
        val h = hint
        if (h != null) {
            Text(
                h, Modifier.align(Alignment.TopCenter).padding(top = 140.dp).clip(RoundedCornerShape(50))
                    .background(Color(0xAA000000)).padding(horizontal = 20.dp, vertical = 10.dp),
                color = white, fontSize = 18.sp
            )
        }
    }
}
